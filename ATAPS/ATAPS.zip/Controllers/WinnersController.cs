﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ATAPS.Controllers
{
    public class WinnersController : Controller
    {
        // GET: Winners
        public ActionResult Index()
        {
            return View();
        }
    }
}